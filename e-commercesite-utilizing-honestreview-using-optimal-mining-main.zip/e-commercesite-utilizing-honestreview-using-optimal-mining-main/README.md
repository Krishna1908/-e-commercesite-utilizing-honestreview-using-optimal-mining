## ITA Project
Fake Product Review Monitoring and Product Evaluation using Opinion Mining

### The project team:
* K.Manoj KUMAR 
*Bharath Reddy 
